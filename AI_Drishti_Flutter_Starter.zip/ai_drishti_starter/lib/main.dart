import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:image/image.dart' as img;
import 'package:sensors_plus/sensors_plus.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  List<CameraDescription> cameras = [];
  try {
    cameras = await availableCameras();
  } catch (_) {
    // The app still opens and explains if no camera is available.
  }
  runApp(AiDrishtiApp(cameras: cameras));
}

class AiDrishtiApp extends StatelessWidget {
  const AiDrishtiApp({super.key, required this.cameras});
  final List<CameraDescription> cameras;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Drishti',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF20C7A5),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF090E12),
        useMaterial3: true,
      ),
      home: CameraHome(cameras: cameras),
    );
  }
}

enum GuideGrid { none, thirds, golden }

class CameraHome extends StatefulWidget {
  const CameraHome({super.key, required this.cameras});
  final List<CameraDescription> cameras;

  @override
  State<CameraHome> createState() => _CameraHomeState();
}

class _CameraHomeState extends State<CameraHome> {
  CameraController? _controller;
  StreamSubscription<AccelerometerEvent>? _sensorSub;
  double _tilt = 0;
  GuideGrid _grid = GuideGrid.thirds;
  bool _busy = false;
  String _status = 'ವಿಷಯವನ್ನು ಫ್ರೇಮ್‌ನಲ್ಲಿ ಇರಿಸಿ';
  List<String> _labels = [];
  String _exposure = 'ಫೋಟೋ ತೆಗೆದ ನಂತರ ಬೆಳಕನ್ನು ಪರಿಶೀಲಿಸಿ';
  final ImageLabeler _labeler = ImageLabeler(
    options: ImageLabelerOptions(confidenceThreshold: 0.55),
  );

  @override
  void initState() {
    super.initState();
    _initCamera();
    _sensorSub = accelerometerEvents.listen((event) {
      // Approximate roll angle when the phone is held in portrait orientation.
      final angle = math.atan2(event.x, event.y) * 180 / math.pi;
      if (mounted) setState(() => _tilt = angle);
    });
  }

  Future<void> _initCamera() async {
    if (widget.cameras.isEmpty) {
      setState(() => _status = 'ಕ್ಯಾಮೆರಾ ಲಭ್ಯವಿಲ್ಲ. Permission ಪರಿಶೀಲಿಸಿ.');
      return;
    }
    final camera = widget.cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => widget.cameras.first,
    );
    final controller = CameraController(
      camera,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.yuv420,
    );
    try {
      await controller.initialize();
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() {
        _controller = controller;
        _status = 'ಕ್ಯಾಮೆರಾ ಸಿದ್ಧವಾಗಿದೆ';
      });
    } on CameraException catch (e) {
      setState(() => _status = 'ಕ್ಯಾಮೆರಾ ದೋಷ: ${e.description ?? e.code}');
    }
  }

  Future<void> _captureAndAnalyze() async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized || _busy) return;
    setState(() {
      _busy = true;
      _status = 'ಫೋಟೋ ವಿಶ್ಲೇಷಿಸಲಾಗುತ್ತಿದೆ...';
      _labels = [];
    });

    try {
      final shot = await controller.takePicture();
      final file = File(shot.path);

      // On-device ML Kit image labeling.
      final input = InputImage.fromFilePath(file.path);
      final results = await _labeler.processImage(input);
      final labels = results
          .take(5)
          .map((e) => '${e.label} (${(e.confidence * 100).round()}%)')
          .toList();

      // Basic image luminance estimate. This is image processing, not AI.
      final bytes = await file.readAsBytes();
      final decoded = img.decodeImage(bytes);
      String exposure = 'ಬೆಳಕು ಪರಿಶೀಲಿಸಲಾಗಲಿಲ್ಲ';
      if (decoded != null) {
        final sample = img.copyResize(decoded, width: 160);
        double total = 0;
        int count = 0;
        for (final pixel in sample) {
          total += img.getLuminance(pixel);
          count++;
        }
        final average = count == 0 ? 0 : total / count;
        if (average < 65) {
          exposure = 'ಚಿತ್ರ ಕತ್ತಲಾಗಿದೆ. ಬೆಳಕಿನ ಕಡೆಗೆ ಸರಿಯಿರಿ ಅಥವಾ exposure ಹೆಚ್ಚಿಸಿ.';
        } else if (average > 190) {
          exposure = 'ಚಿತ್ರ ತುಂಬಾ ಪ್ರಕಾಶಮಾನವಾಗಿದೆ. ಬೆಳಕಿನ ಮೂಲವನ್ನು ಕಡಿಮೆ ಮಾಡಿ.';
        } else {
          exposure = 'ಬೆಳಕು ಸಮತೋಲನದಲ್ಲಿದೆ. ಚೆನ್ನಾಗಿದೆ!';
        }
      }

      if (!mounted) return;
      setState(() {
        _labels = labels;
        _exposure = exposure;
        _status = 'ವಿಶ್ಲೇಷಣೆ ಪೂರ್ಣಗೊಂಡಿದೆ';
      });
      _showAnalysisSheet(file.path, labels, exposure);
    } catch (e) {
      if (mounted) setState(() => _status = 'ವಿಶ್ಲೇಷಣೆ ವಿಫಲ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showAnalysisSheet(String path, List<String> labels, String exposure) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF151E24),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('AI Photo Analysis',
                    style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.file(File(path), height: 190, width: double.infinity, fit: BoxFit.cover),
                ),
                const SizedBox(height: 16),
                const Text('ದೃಶ್ಯ ಗುರುತಿಸುವಿಕೆ', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(labels.isEmpty ? 'ಯಾವುದೇ label ಪತ್ತೆಯಾಗಿಲ್ಲ.' : labels.join('\n')),
                const SizedBox(height: 14),
                const Text('ಬೆಳಕಿನ ಸಲಹೆ', style: TextStyle(fontWeight: FontWeight.bold)),
                Text(exposure),
                const SizedBox(height: 14),
                const Text('ಗಮನಿಸಿ: ML Kit labels ದೃಶ್ಯವನ್ನು ಗುರುತಿಸುತ್ತವೆ. Exposure ಅಂದಾಜು ಸರಳ image processing ಆಧಾರಿತವಾಗಿದೆ; ಇದು DSLR‌ನ ನಿಖರ ISO/shutter metering ಅಲ್ಲ.',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _sensorSub?.cancel();
    _controller?.dispose();
    _labeler.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ready = _controller?.value.isInitialized == true;
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI ದೃಷ್ಟಿ', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          PopupMenuButton<GuideGrid>(
            icon: const Icon(Icons.grid_on),
            tooltip: 'Grid ಆಯ್ಕೆ',
            onSelected: (value) => setState(() => _grid = value),
            itemBuilder: (_) => const [
              PopupMenuItem(value: GuideGrid.none, child: Text('Grid ಇಲ್ಲ')),
              PopupMenuItem(value: GuideGrid.thirds, child: Text('Rule of Thirds')),
              PopupMenuItem(value: GuideGrid.golden, child: Text('Golden Ratio Guide')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (ready)
                  CameraPreview(_controller!)
                else
                  Center(child: Text(_status, textAlign: TextAlign.center)),
                if (ready && _grid != GuideGrid.none)
                  IgnorePointer(child: CustomPaint(painter: GridPainter(_grid))),
                if (ready)
                  Positioned(
                    top: 18,
                    left: 0,
                    right: 0,
                    child: Center(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: 0.55),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'Level: ${_tilt.abs().toStringAsFixed(1)}° ${_tilt.abs() < 2.5 ? '✓' : 'ಫೋನ್ ನೇರಗೊಳಿಸಿ'}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ),
                if (ready)
                  Positioned(
                    bottom: 18,
                    left: 16,
                    right: 16,
                    child: Text(_status, textAlign: TextAlign.center,
                        style: const TextStyle(shadows: [Shadow(blurRadius: 8, color: Colors.black)])),
                  ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 22),
            decoration: const BoxDecoration(
              color: Color(0xFF11191F),
              borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
            ),
            child: Column(
              children: [
                Text(_exposure, textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      onPressed: () => setState(() {
                        _grid = _grid == GuideGrid.thirds ? GuideGrid.golden : GuideGrid.thirds;
                      }),
                      icon: const Icon(Icons.grid_4x4),
                      tooltip: 'Grid ಬದಲಿಸಿ',
                    ),
                    const SizedBox(width: 24),
                    GestureDetector(
                      onTap: _busy ? null : _captureAndAnalyze,
                      child: Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 5),
                        ),
                        child: Center(
                          child: _busy
                              ? const SizedBox(width: 25, height: 25, child: CircularProgressIndicator(strokeWidth: 2))
                              : Container(
                                  width: 54,
                                  height: 54,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF20C7A5),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 24),
                    IconButton(
                      onPressed: ready ? _captureAndAnalyze : null,
                      icon: const Icon(Icons.auto_awesome),
                      tooltip: 'AI ವಿಶ್ಲೇಷಣೆ',
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text('ಫೋಟೋ ತೆಗೆಯಿರಿ ಮತ್ತು AI ವಿಶ್ಲೇಷಿಸಿ',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class GridPainter extends CustomPainter {
  GridPainter(this.grid);
  final GuideGrid grid;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withValues(alpha: 0.72)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    if (grid == GuideGrid.thirds) {
      for (int i = 1; i <= 2; i++) {
        final x = size.width * i / 3;
        final y = size.height * i / 3;
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
        canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
      }
    } else {
      // Golden-ratio guide: approximate nested rectangles.
      final rect = Rect.fromLTWH(0, 0, size.width, size.height);
      final x1 = size.width * 0.382;
      final x2 = size.width * 0.618;
      final y1 = size.height * 0.382;
      final y2 = size.height * 0.618;
      canvas.drawLine(Offset(x1, 0), Offset(x1, size.height), paint);
      canvas.drawLine(Offset(x2, 0), Offset(x2, size.height), paint);
      canvas.drawLine(Offset(0, y1), Offset(size.width, y1), paint);
      canvas.drawLine(Offset(0, y2), Offset(size.width, y2), paint);
      canvas.drawRect(rect.deflate(2), paint);
    }
  }

  @override
  bool shouldRepaint(covariant GridPainter oldDelegate) => oldDelegate.grid != grid;
}
