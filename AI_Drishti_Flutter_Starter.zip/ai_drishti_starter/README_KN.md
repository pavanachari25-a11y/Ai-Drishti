# AI Drishti – ಆರಂಭಿಕ Flutter Project

ಈ ZIP ಒಂದು **starter source project**. ಇದು ಈಗಾಗಲೇ ಕೆಳಗಿನ ಕಾರ್ಯಗಳನ್ನು ಒಳಗೊಂಡಿದೆ:
- ಹಿಂದಿನ ಕ್ಯಾಮೆರಾ preview
- Rule of Thirds ಮತ್ತು Golden Ratio guide overlay
- Accelerometer ಆಧಾರಿತ ಸರಳ horizon/tilt ಸೂಚನೆ
- ಫೋಟೋ ತೆಗೆದು Google ML Kit ಮೂಲಕ on-device image labels
- ಸರಳ ಸರಾಸರಿ brightness ಆಧಾರಿತ exposure ಸಲಹೆ

## ಮುಖ್ಯ ಮಿತಿ
ಇದು ಇನ್ನೂ ಪೂರ್ಣ Play Store-ready ಉತ್ಪನ್ನವಲ್ಲ. AI scene labels ಮತ್ತು brightness ಸೂಚನೆಗಳು ಕಾರ್ಯನಿರ್ವಹಿಸುವ ಆರಂಭಿಕ ಹಂತ. ನಿಖರ ISO/shutter speed ನಿಯಂತ್ರಣ, real-time AI frame analysis, leading-line detection, user accounts, subscriptions ಮತ್ತು ads ಮುಂದಿನ ಹಂತಗಳಲ್ಲಿ ಸೇರಿಸಬೇಕು.

## ಮೊಬೈಲ್‌ನಿಂದ ನಿರ್ಮಿಸುವ ವಿಧಾನ

1. Android ಫೋನ್‌ನಲ್ಲಿ Chrome ತೆರೆಯಿರಿ.
2. Flutter ಅನ್ನು ಬೆಂಬಲಿಸುವ cloud development/build ಸೇವೆಯಲ್ಲಿ ಖಾತೆ ತೆರೆಯಿರಿ (ಉದಾ. GitHub Codespaces ಅಥವಾ Codemagic). ಸೇವೆಗಳ ಉಚಿತ ಮಿತಿಗಳು ಬದಲಾಗಬಹುದು.
3. ಹೊಸ Flutter project ರಚಿಸಿ: `flutter create ai_drishti`
4. ಈ ZIP‌ನ `pubspec.yaml` ಮತ್ತು `lib/main.dart` ಅನ್ನು ನಿಮ್ಮ project‌ನಲ್ಲಿರುವ ಅದೇ ಫೈಲ್‌ಗಳಿಂದ ಬದಲಾಯಿಸಿ.
5. Terminal ನಲ್ಲಿ ಓಡಿಸಿ:
   - `flutter pub get`
   - `flutter analyze`
   - `flutter build apk --release`
6. APK ಸಾಮಾನ್ಯವಾಗಿ `build/app/outputs/flutter-apk/app-release.apk` ನಲ್ಲಿ ಸಿಗುತ್ತದೆ.
7. APK ಅನ್ನು ನಿಮ್ಮ ಫೋನ್‌ಗೆ ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ. Android ಕೇಳಿದರೆ ಆ ಮೂಲದಿಂದ app install ಮಾಡಲು ಅನುಮತಿ ನೀಡಿ.

## iOS
ಅದೇ Flutter code iOS ಗೂ ಬಳಸಬಹುದು. ಆದರೆ iOS build ಗೆ macOS/Xcode ಅಥವಾ macOS cloud build ಸೇವೆ ಮತ್ತು ಅಗತ್ಯವಿದ್ದರೆ Apple Developer account ಬೇಕಾಗುತ್ತದೆ.

## Android permission
`camera` plugin ಸಾಮಾನ್ಯವಾಗಿ camera permission ನಿರ್ವಹಿಸುತ್ತದೆ. Build ಮಾಡಿದ ನಂತರ ಮೊದಲ ಬಾರಿ camera permission ಕೇಳಿದಾಗ Allow ಒತ್ತಿರಿ. Android project‌ನ `minSdk` ML Kit ಬೆಂಬಲಿಸುವ ಮಟ್ಟದಲ್ಲಿರಬೇಕು (ಸಾಮಾನ್ಯವಾಗಿ 21 ಅಥವಾ ಮೇಲು).

## ಮುಂದಿನ ಅಭಿವೃದ್ಧಿ
- Real-time frame sampling + lightweight on-device model
- Manual exposure controls (ಫೋನ್ camera hardware ಬೆಂಬಲಿಸಿದರೆ ಮಾತ್ರ)
- Composition scoring
- ಕನ್ನಡ/ಇಂಗ್ಲಿಷ್ coach explanations
- Firebase, privacy policy, monetization ಮತ್ತು Play Store release
